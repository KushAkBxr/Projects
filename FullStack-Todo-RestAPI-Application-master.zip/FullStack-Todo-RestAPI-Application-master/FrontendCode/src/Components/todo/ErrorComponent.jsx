import './TodoApp.css'

function ErrorComponent(){
    return (
        <div className="ErrorComponent">
            <h1>We are working on it</h1>
            <div>Apologies for the 404</div>
        </div>
    )
}

export default ErrorComponent;