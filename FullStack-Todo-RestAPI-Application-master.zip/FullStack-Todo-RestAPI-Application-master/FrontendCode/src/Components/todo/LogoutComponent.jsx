function LogoutComponent(){
    return(
        <div className="LogoutComponent">
        <h1>Thank you for using our website</h1>
        Come back soon!
        </div>
    )
}

export default LogoutComponent;