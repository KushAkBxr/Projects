import './App.css';
import TodoApp from './Components/todo/TodoApp'

function App() {
  return (
    <div className="App">
    <TodoApp />
    </div>
  );
}

export default App;
