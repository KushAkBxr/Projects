insert into todo (id, description, done, target_date, username)
values (10001, 'Learn AWS', false, CURRENT_DATE(), 'in28minutes');

insert into todo (id, description, done, target_date, username)
values (10002, 'Learn Game Development', false, CURRENT_DATE(), 'Sam');

insert into todo (id, description, done, target_date, username)
values (10003, 'Learn DSA', false, CURRENT_DATE(), 'Hero');

insert into todo (id, description, done, target_date, username)
values (10004, 'Learn Dance', false, CURRENT_DATE(), 'in28minutes');